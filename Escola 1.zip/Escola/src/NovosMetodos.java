/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author 05908897027
 */
public class NovosMetodos {
    
    public static void main(String[] args) {
        MeusDados dados = new MeusDados();
        
        MeusDados.Turma novaTurma = dados.Turmas.get(0);
        MeusDados.Turma outraTurma = dados.Turmas.get(1);
        
        System.out.println( novaTurma );
        System.out.println( outraTurma );
        
        System.out.println( novaTurma.equals(outraTurma) );
        System.out.println( novaTurma.equals(novaTurma));
        
    }
    
}
