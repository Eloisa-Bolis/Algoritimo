/*
Por exemplo, seu chefe pode falar ao telefone "Um, três, cinco, quatro, zero, zero, sete, zero, zero, seis", o que 
significa uma soma total igual a 7, conforme explicado na tabela abaixo:
 */
import java.util.Scanner;

public class ZeroParaCanselar {

    public static void main(String[] args) {
        Scanner leitor = new Scanner(System.in);
        
        int[] num;
        int soma = 0;
        
        
    }
    
}
