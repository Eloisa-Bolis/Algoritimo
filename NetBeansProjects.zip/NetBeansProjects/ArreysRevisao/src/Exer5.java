/*
Escreva um programa em Java que leia 10 números inteiros. Como saída, deve informar se
existe algum igual. Não precisa informar quais são os números, apenas se há duplicatas.
 */
import java.util.Scanner;
public class Exer5 {

    public static void main(String[] args) {
        Scanner leitor = new Scanner(System.in);
        
        int valores [] = new int [10];
        
        for(int i=0; i<valores.length; i++){
            valores[i] = leitor.nextInt();
        }
        for(int i=0; i<valores.length; i++){
            for(int j=i+1; j<valores.length; j++){
                if( valores[i] == valores[j]){
                    System.out.println(valores[i] + " = " + valores[j]);
                } 
            }
        }
    }
    
}
