/*
Escreva um programa em Java que leia 100 números reais e armazene num vetor. Em seguida,
exiba o quadrado e o cubo de cada um dos números.
 */
import java.util.Scanner;
public class cemNum {

    public static void main(String[] args) {
        Scanner leitor = new Scanner(System.in);
        
        int[] num = new int [100]
        
        System.out.println("Escreva 100 numeros");
        for(int i = 0; i < num.length; i++){
            int numHora = leitor.nextInt();
            
            
        }
        
    }
    
}
