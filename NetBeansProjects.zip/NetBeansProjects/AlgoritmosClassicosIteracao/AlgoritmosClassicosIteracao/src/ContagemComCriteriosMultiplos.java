import java.util.Scanner;  
public class ContagemComCriteriosMultiplos {

    
    public static void main(String[] args) {
        
        Scanner leitor = new Scanner(System.in);
        // A variavel contador vai armazenar a quantidade de valores
        int contaPosi = 0; int contaNeg = 0;
        int contaZero = 0; // O ZERO � o elemento neutro da soma
        int valor; // variavel que ira receber cada numero informado

        for (int i = 0; i < 10; i++) {
            valor = leitor.nextInt();
            
            // Nese comando condicional � especificado o CRITERIO para realizar
            // a contagem do valor.
            if (valor > 0) {
                // comando classico de CONTAGEM: incremento simples (++)
                contaPosi++;
            } else {
                if(valor < 0) {
                contaNeg++;
                
                } else {
                    contaZero++;
                }
            }
        }
        System.out.println("positivo:" + contaPosi);
        System.out.println("negativo:" + contaNeg);
        System.out.println("zero:" + contaZero);
    }   
}
