/**
 * Algoritmo Classico de Somatorio de Uma Quantidade Indefinida de Numeros
 * at� que seja atingido um valor LIMITE para o somatorio.
 * Exemplo com leitura de N numeros inteiros informados pelo usuario. Aqui, o
 * usuario informa inicialmente o limite maximo a ser atingido.
 * 
 * @author Alexandro Adario <alexandro.adario@erechim.ifrs.edu.br>
 */
import java.util.Scanner;

public class SomatorioComLimiteMaximo {

    public static void main(String[] args) {
        Scanner leitor = new Scanner(System.in);
        // A variavel soma vai armazenar a acumula��o (somatorio) dos valores
        int soma = 0; // O ZERO � o elemento neutro da soma
        int valor; // variavel que ira receber cada numero informado
        int somaTemp = 0;
        
        int limite = leitor.nextInt();
        
        // A cada nova "acumulacao", a vari�vel soma � testada para verificar se
        // o limite foi ultrapassado. Quando isso ocorre o loop while encerra.
        while(somaTemp < limite) {   
            valor = leitor.nextInt();
            // comando classico de ACUMULACAO: usa o valor anterior de "soma",
            // adiciona um novo "valor" e armazena novamente em "soma"
            somaTemp = somaTemp + valor; 
            if(somaTemp <= limite ) {
                soma = somaTemp;
            }
        }
        System.out.println(somaTemp);
        System.out.println(soma);
    }
}