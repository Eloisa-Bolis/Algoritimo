/*
metodo para calcular as raizes reais de uma equacao do 2 grau. Os parametro de entrada sao os 
coeficientes a,b,c. O retorno e um array contendo duas raizes( se houver apenas 1 raiz, o arrey tera 1 posicao se nao 
houver raiz retorna null)
 */
public class Equacao2grau {
    public static double[] segndograu (double a, double b, double c) {
        
        double num;mn  
        double X2 = Math.pow(num, 2);
    }
    
}
