import java.util.Scanner;

import java.util.ArrayList;

public class UsandoListas {
    public static void main(String[] args) {
        Scanner leitor = new Scanner(System.in);
        
        ArrayList< String > minhaLista = new ArrayList();
        
        int NumElementos = minhaLista.size();
        System.out.println("Numero de elementos: " + NumElementos);
        //(size)quantidade de elementos
        
        boolean estaVazia = minhaLista.isEmpty();
        System.out.println("Esta vazia? " + estaVazia);
        //(isEmpty)ver se tem algo dentro sim ou não
        
        minhaLista.add("banana");  //0
        minhaLista.add("leite");   //1
        minhaLista.add("pao");     //2
        minhaLista.add("presunto");//3
        minhaLista.add("leite condensado");//4
        //(add)adicina na memoria as coisas ne ordem que foi colocada
        //vai sempre adicionar no final da lista, mesmo se ja tiver
        
        String elemento = minhaLista.get(2);
        System.out.println(elemento);
        //aqui ele pega o elemento do indice escolido no caso(pao)
        
        minhaLista.add(2, "desinfetante");
        //ele insere no meio 2=desinfetante 3=pao 4=presunto...
        
        boolean encontrou = minhaLista.contains("vasoura");
        System.out.println("Encontro vassoura?" + encontrou);
        //(contains) serve para ver se tem ou nao ex=false
        encontrou = minhaLista.contains("leite");
        System.out.println("Encontro vassoura?" + encontrou);
        //(contains) serve para ver se tem ou nao ex=true
        
        int indice = minhaLista.indexOf("presunto");
        System.out.println("Indice de presunto: " + indice);
        //(indexOf) procura em que indice o item esta ex= 4
        indice = minhaLista.indexOf("batata");
        System.out.println("Indice de presunto: " + indice);
        //(indexOf) caso não tenha vai ir = -1
        
        
        minhaLista.remove("banana"); 
        minhaLista.remove(0);
        //(remove)remove a "banana".  0="leite" 1="desifetante"
        
        boolean remove = minhaLista.remove("pao");
        // remove e fala true
        remove = minhaLista.remove("cafe");
        // fala false porque nao existe esse item
        
    }
    
}
