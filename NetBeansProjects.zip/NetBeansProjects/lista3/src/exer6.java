public class exer6 {

    public static void main(String[] args) {
        int tI =20;
        int tA = tI;
        int tL = 5000000;
        int contador = 0;
        while (tA < tL ){
            contador += 5;
            tA = tA * 2;
            System.out.println("dias=" + contador);
            System.out.println("Tam.Atual=" + tA);  
        }
    }
    
}
