import java.util.Scanner;
public class exer13_4 {

    
    public static void main(String[] args) {
        Scanner leitor = new Scanner(System.in);
        
        double aI = 1.5;
        double aAtu = aI;
        double taxaCresc = leitor.nextDouble();
        double aF = leitor.nextDouble();
        int ano = 0;
        
        while( aAtu < aF ){
            ano++;
            aAtu = aAtu * (1.0 +taxaCresc/100.0);
            System.out.println("Ano " + ano + ": " + aAtu);
            
        }
    }
    
}
