public class exer1 {

    public static void main(String[] args) {
    
        for(int i=1, j=60; j >= 0; i += 3, j -=5){
            System.out.println("j = " + j + " i = " + i );
        }
    }   
}
