
public class exer2 {

    public static void main(String[] args) {
        
        for(int i = 1; i <=9; i+=2){
            for(int j=7; j >= 5; j --){
                System.out.println("i=" + i + " j=" + j );
            }
        }
            
    }
    
}
