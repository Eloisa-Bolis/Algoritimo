public class MinhasContas {

    public static void main(String[] args) {
        System.out.println("Meus Calculos");
        System.out.println(1247-351);
        System.out.println(391*14);
    }
    
}
