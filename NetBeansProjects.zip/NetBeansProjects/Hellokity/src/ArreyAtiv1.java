import java.util.Scanner;
public class ArreyAtiv1 {
    public static void main(String[] args) {
        Scanner leitor = new Scanner(System.in);
        
        double[] Ele = new double [10];
        double soma = 0;
        double med = 0;

                
        for(int i=0; i<Ele.length; i++){
            Ele[i] = leitor.nextDouble();
              
        }
        for(int i=0; i<Ele.length; i++){    
            soma += Ele[i];
            
        }

        med = soma/10;
        System.out.println("O resultato da media eh:" + med);
        
    }
    
}
