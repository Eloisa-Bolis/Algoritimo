
public class Exercicio_cpf {
    
    public static void main(String[] args) {
        
        String myCPF = "05908897027";
        
        for(int n=0; n < myCPF.length(); n++ ) {
  //          char digi = mycpf.charAt( n );
            String digiS = myCPF.substring( n, n+1);
            int digito = Integer.parseInt( digiS );
            
            System.out.println(digiS + " - " + (digito*2) );
 //           System.out.prinln(digi + " - " + digis );
    }       
       
            
    }
    
}
