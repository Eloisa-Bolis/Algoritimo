 
/*
        criação de arrays
        numeros = new int [20]
        palavreas = new string [10]
        valores = new doble [4] [20]
        contas = new bolean [5]
        
        *começa sempre do zero
        
        int [5] [i] *nome
        
        vetor = new int[10]
        vetor[1] = 135;
        *o "andar" 1 vai ficar com o valor 135
        
        *assim vc pode mudar o valor em caso de um laço ou algo do tipo
        */


import java.util.Scanner;
public class Arrays {
    public static void main(String[] args) {
        Scanner leitor = new Scanner(System.in);
        
        int[] variavel = new int [10];
        
        for(int indice=0; indice <10; indice++) {           
//      for(int indice=0; indice <length; indice++) {  *assim se voce quiser almentar o arrays não precisa mudar o laço            
            variavel[indice] = leitor.nextInt();
        }
        
        for(int indice=0; indice <10; indice++) {
//      for(int indice=0; indice <length; indice++) {  *assim se voce quiser almentar o arrays não precisa mudar o laço            
            System.out.println( variavel[indice] );
        }
    
        
    }
    
}
