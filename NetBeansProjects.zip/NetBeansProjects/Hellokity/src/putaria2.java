/*
terminar
perimetro,
area do circulo,
volume da esfera,
area superficial.
*/


import java.util.Scanner;
public class putaria2 {
    public static void main(String[] args) {
        Scanner leitor = new Scanner(System.in);
        System.out.println("Qual a medida do raio");
        
        int raio = leitor.nextInt();
        
        double diametro = raio + raio;
        
        int perimetro = (int) (diametro * Math.PI);
        System.out.println("O perimetro eh: " + perimetro);
        
        
    }
    
}
