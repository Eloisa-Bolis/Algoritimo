public class ExcecaoNaoVerificada {
    
    public static void main(String[] args) {
        int[] vetor = new int [10];
        try{
            for (int i = 0; i<= 10; i++) {
                vetor [i] = i * 2;
            }
        } catch (IndexOutOfBoundsException exc) {
            
        }
        System.out.println("");
    }
}
