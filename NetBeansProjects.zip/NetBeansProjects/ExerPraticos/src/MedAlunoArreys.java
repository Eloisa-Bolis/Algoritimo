/*
 10 alunos. Armazenar nome+2notas// Media de cada aluno + por prova + media geral// Nota max+mini.
Maior e menor media. quantos estao abaixo e acima da media geral
 */
import java.util.Scanner;
public class MedAlunoArreys {

    public static void main(String[] args) {
        Scanner leitor = new Scanner(System.in);
        
        String [] Nomes = new String[10];
        double [][] Notas = new double [10][2];
        
         System.out.println("nome do aluno");
        
        for(int i=0 ; i<10 ; i++ ){
            Nomes [i] = leitor.nextLine();   
        //Não colocar nextLine e double junto porque buga    
        }
        for(int a=0 ; a<10 ; a++){
            System.out.println("notas de "  + Nomes[a]);
            for(int n=0 ; n<2 ; n++){
                Notas[a][n] = leitor.nextDouble();
            }
        }
        // apartir daqui ei nao entendi nada
        double[] MediaAluno = new double [10];
        double[] MediaAvaliacao = new double [2];
        double MediaGeral;
        
        for(int alu=0 ; alu<10 ; alu++){
            
            for(int n=0 ; n<2 ; n++){
               MediaAluno[alu] += Notas[alu][n];
               MediaAvaliacao[n] += Notas[alu][n];
            }
            MediaAluno[alu]/= 2.0;
            
            System.out.println("Media aluno " + Nomes [1] + MediaAluno [1]);
        }
        MediaAvaliacao[0]/= 10.0;
        MediaAvaliacao[1]/= 10.0;
        MediaGeral =(MediaAvaliacao[0] + MediaAvaliacao[1])/2.0;
        
        
        System.out.println("Media Avaliaca " + MediaAvaliacao [0]);
        System.out.println("Media Avaliaca " + MediaAvaliacao [1]);

        System.out.println("Media Geral " + MediaGeral);
        
        
      
        double Max = MediaAluno[0];
        double Min = MediaAluno[0];
        
        for(int n=1 ; n<MediaAluno.length ; n++){
            if(MediaAluno[n] > Max){
               Max = MediaAluno[n]; 
            }
            if(Min > MediaAluno[n]){
               Min = MediaAluno[n]; 
            }   
        }
          
        double [] maxNota = new double[2];
        double [] minNota = new double[2]; 
        
        for(int n=0 ; n<maxNota.length ; n++){
            maxNota[n] = Notas[0][n];
            minNota[n] = Notas[0][n];
        }
        for(int a=1 ; a<Notas.length ; a++){       //porque começa com 0?
            for(int n=0 ; n<Notas[a].length ; n++){
                if(Notas[a][n] > maxNota[n]){
                    maxNota[n] = Notas[a][n]; 
                }
                if(Notas[a][n] < minNota[n]){
                    minNota[n] = Notas[a][n]; 
                }    
            }
        }
            
            
    /*     double MaiorNota = Notas[0][0];
        double MenorNota = Notas[0][0];
        
        for(int F=1 ; F<10 ; F++){
            for(int M=0 ; M<Notas.length ; M++){
                if(Notas[F][M] > MaiorNota){
                    MaiorNota = Notas[F][M]; 
                }
                if(Notas[F][M] < MenorNota){
                    MenorNota = Notas[F][M]; 
                }    
            }   nesse ele pega a maior e a menor nota de todas
                 
        } 
    */
        
        System.out.println("Media Max " + Max);
        System.out.println("Media Min" + Min);
        System.out.println("Nota Max" + maxNota);
        System.out.println("Nota Max" + minNota);
    }
    
}
