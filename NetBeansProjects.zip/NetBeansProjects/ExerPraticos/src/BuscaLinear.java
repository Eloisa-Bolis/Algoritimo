/*

 */
public class BuscaLinear {
    
    static final int TAMANHO = 10_000_000;
    static int[] vetor = new int [TAMANHO];
    
    public static void main(String[] args) {
        
        for(int i=0; i< vetor.length; i++){
            vetor[i] = (int) Math.rint( Math.random() * 1_000_000 );
        }
                
        
                 // Busca linear **
                 
        
        for(int i = 0; i < 100; i++) {                                          //?
            int comp;
            int numero = (int) Math.rint( Math.random() * 1_000_000 );
            
            long inicio = System.currentTimeMillis(); 
            //mede quantos mini segundos leva pra executar o codigo
            
            for(comp = 0; comp < vetor.length && numero != vetor[comp]; comp++){                
            }
            long fim = System.currentTimeMillis();
            //mede quantos mini segundos leva pra executar o codigo
                   
                          // busca Binaria  **
            
            int incio = 0; fim = vetor.length - 1;
            int pivo;
            
            do {
                pivo = (int) ((inicio + fim) /2);
                if( numero /*chave*/ > vetor[pivo]){     //chave maior que
                    inicio = pivo +1;
                } else {
                    
                    if( numero/*chave*/ < vetor[pivo] ) {
                        fim = pivo -1;
                    }
                }
            } while ( numero /*chave*/ != vetor[pivo] &&
                inicio <= fim );
                // fim > inicio
                if( inicio > fim ) {
                //nao encontrou
                } else {
                //encontrou
                // posicao = pivo
                }
                
                
            System.out.println("Comparacoes: " + comp + " " + (fim - inicio) + "ms");    

        }         
    }
    
}
