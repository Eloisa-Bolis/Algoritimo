import java.util.Scanner;
public class busca_binario {

    public static void main(String[] args) {
        Scanner leitor = new Scanner(System.in);
        
        int[] V = {3, 5, 7, 9, 11, 13, 15, 17, 58, 100, 164, 190, 257, 270, 296, 389, 399, 457};
        
        int chave = leitor.nextInt();
        
        int inicio = 0;
        int fim = V.length - 1;
        int pivo;
        
        /*
        if( chave < V[pivo]){     //chave menor que
                inicio = pivo +1;
            } else {                                       //decresente
                if( chave > V[pivo] ) {
                    fim = pivo -1;
                }
            }
        */
        do {
            pivo = (inicio + fim) /2;
            if( chave > V[pivo]){     //chave maior que
                inicio = pivo +1;
            } else {
                if( chave < V[pivo] ) {
                    fim = pivo -1;
                }
            }
        } while (chave != V[pivo] &&
            inicio <= fim );
            // fim > inicio
            
        if( inicio > fim ) {
            System.out.println("Nao encontrou");//nao encontrou
        } else {
            System.out.println("Encontro");//encontrou
            System.out.println(chave + " = " + pivo);// posicao = pivo
        }
    } 
}
