/*
incremente o valor depois 
numero ++;
numero = numero + 1;
numero += 1;
*/
public class Leitura2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
