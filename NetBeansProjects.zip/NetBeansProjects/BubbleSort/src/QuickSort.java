public class QuickSort {

    public static void partition(int[] vetor, int inicio, int fim) {
        
    }
            
    public static void
    
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
