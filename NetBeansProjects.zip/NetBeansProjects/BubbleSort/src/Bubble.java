public class Bubble {

    public static void sort(int[] vetor) {
        //rodadas de conparacao
        for(int i=0; i < vetor.length - 1; i++){
            // sequencia de comparacoes (do inicio ao fim
            for(int j=0; j < vetor.length - i -1; j++){
                // se j for maior que j+1 troca
                if( vetor[j] > vetor[j+1]){
                    int temp = vetor[j];
                    vetor[j] = vetor[j+1];
                    vetor[j+1] = temp;
                }
            }
        }
        
    }
    
    public static void main(String[] args) {
        int[] numeros = GeradorAleatorio.geraInt(20, 0, 1000);
        
        for(int numero : numeros){
            System.out.print(numero + " ");
        }
        System.out.println();
        
        Bubble.sort(numeros);
        
        for(int numero : numeros) {
            System.out.print(numero + " ");
        } 
        System.out.println();
    }
}
