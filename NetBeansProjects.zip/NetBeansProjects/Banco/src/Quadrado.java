/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author 05908897027
 */
public class Quadrado {
    
    private double lado;
    
    public void setLado( double valor ) {
        this.lado = valor;
    }
    
    public double calcArea() {
        return lado * lado;
    }
    
    public double getLado( ) {
        return this.lado;
    }
            
}
