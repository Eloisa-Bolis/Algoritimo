public class Movimento {
    
    int disco;
    char origem, destino;

    Movimento(int disco, char origem, char destino) {
        this.disco = disco;
        this.origem = origem;
        this.destino = destino;
        
    }
}
//o codigo move um disco de uma torre para outra