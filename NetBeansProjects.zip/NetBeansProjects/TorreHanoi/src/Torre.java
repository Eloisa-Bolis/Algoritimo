/*
começa aqui
 */
import java.util.Scanner;
import java.util.Stack;

public class Torre {

    public static void main(String[] args) {
        Scanner leitor = new Scanner(System.in);       
        
        System.out.println("Digite o numeros de discos para saber quantos movimentos serao precisos");
        int discos = leitor.nextInt();
        double movimentos = Math.pow(2, discos) - 1;
        System.out.println("Serao necessario " + movimentos + " movimentos");
        
        
        Stack<Movimento> pilha = new Stack<>();
        
    }
    
}
        
    }
    
}