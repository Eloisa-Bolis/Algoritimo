import java.util.Scanner;
public class WhileSome10 {
    public static void main(String[] args) {
        Scanner leitor = new Scanner (System.in);
        
        int numero, soma = 0;
        
        numero = leitor.nextInt();
        while (numero >0) {
            
            soma = soma + numero;
            numero = leitor.nextInt();
            
        }
        System.out.println("soma:" + soma);
        
        /*
        do {
            numero = leitor.nextInt();
            if( numero > 0 ) {
                soma = soma + numero;
            }
        } while (numero = 0);
        System.out.println("soma:" + soma);
        */
                
        
    }
    
}
