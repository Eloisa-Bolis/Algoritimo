
public class CuboNumeros {
    public static void main(String[] args) {
        for(int numero=5; numero<=27; numero++) {
            System.out.println( "O cubo de " + numero +
                    ":" + (numero*numero*numero) );
        }
    }
    
}
