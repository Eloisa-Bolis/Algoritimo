
public class loop {    
    public static void main(String[] args) {
        
        for( int numero=1; numero <= 100; numero++ ) {
            if(numero%3 == 0 // numero%7 == 0 ) {
                System.out.println(numero);
            } 
        }
    }
    
}
